"use server"

import { createClient } from "@/lib/supabase/server"
import type { OnboardingData } from "@/lib/validations/onboarding"

export async function saveOnboardingProgress(
  step: number,
  data: Partial<OnboardingData>,
  _isCompleted: boolean = false
) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) throw new Error("Unauthorized")

  const profileUpdate: Record<string, string | number | string[]> = {
    onboarding_step: Math.min(Math.max(step, 1), 7),
    // NOTE: 'status' is RLS-protected and cannot be set here.
    // It is updated via POST /api/onboarding/complete using the admin client.
  }

  // Map Step 1
  if (data.full_name) profileUpdate.full_name = data.full_name;
  if (data.date_of_birth) profileUpdate.date_of_birth = data.date_of_birth;
  if (data.gender === 'male' || data.gender === 'female') profileUpdate.gender = data.gender;
  if (data.phone_number) profileUpdate.phone_number = data.phone_number;
  if (data.height_cm) profileUpdate.height_cm = data.height_cm;
  if (data.avatar_url) profileUpdate.profile_photo_path = data.avatar_url;

  // Map Step 2
  if (data.city) profileUpdate.town = data.city;
  if (data.religion) profileUpdate.religion = data.religion;
  if (data.caste) profileUpdate.caste = data.caste;
  if (data.sub_caste) profileUpdate.sub_caste = data.sub_caste;

  // Map Step 3
  if (data.education) profileUpdate.education = data.education;
  if (data.occupation) profileUpdate.profession = data.occupation;
  // Income range mapping (Frontend sends a number, DB expects a bucket enum)
  if (typeof data.income_annual === 'number') {
    const inc = data.income_annual;
    if (inc < 300000) profileUpdate.income_range = '<3L';
    else if (inc < 600000) profileUpdate.income_range = '3-6L';
    else if (inc < 1000000) profileUpdate.income_range = '6-10L';
    else if (inc < 2000000) profileUpdate.income_range = '10-20L';
    else profileUpdate.income_range = '20L+';
  }
  if (data.bio) profileUpdate.about_me = data.bio;

  // Map Step 4
  if (data.family_type === 'nuclear' || data.family_type === 'joint') {
    profileUpdate.family_type = data.family_type;
  }
  if (data.father_occupation) profileUpdate.father_occupation = data.father_occupation;
  if (data.siblings) profileUpdate.siblings_count = parseInt(data.siblings) || 0;
  if (data.gotra) profileUpdate.gotra = data.gotra;
  if (data.mothers_gotra) profileUpdate.mothers_gotra = data.mothers_gotra;
  if (data.grandmothers_gotra) profileUpdate.grandmothers_gotra = data.grandmothers_gotra;

  // Map Step 5
  if (data.manglik === 'yes') profileUpdate.manglik_status = 'manglik';
  else if (data.manglik === 'no') profileUpdate.manglik_status = 'non_manglik';
  else if (data.manglik === 'dont_know') profileUpdate.manglik_status = 'unknown';
  
  if (data.horoscope_details) profileUpdate.horoscope_details = data.horoscope_details;
  if (data.diet) profileUpdate.diet = data.diet;
  if (data.smoking) profileUpdate.smoking = data.smoking;
  if (data.drinking) profileUpdate.drinking = data.drinking;
  if (data.hobbies) profileUpdate.hobbies = data.hobbies;

  // Compile photos array
  const photos: string[] = [];
  if (data.avatar_url) photos.push(data.avatar_url);
  if (data.photo_2) photos.push(data.photo_2);
  if (data.photo_3) photos.push(data.photo_3);
  if (photos.length > 0) profileUpdate.photos = photos;

  // Map Step 6
  if (data.partner_age_min) profileUpdate.preferred_age_min = data.partner_age_min;
  if (data.partner_age_max) profileUpdate.preferred_age_max = data.partner_age_max;
  if (data.partner_location) profileUpdate.preferred_town = data.partner_location;
  if (data.partner_religion) profileUpdate.preferred_religion = data.partner_religion;
  if (data.partner_caste) profileUpdate.preferred_caste = data.partner_caste;

  // Update profiles table
  const { error: profileError } = await supabase
    .from("profiles")
    .update(profileUpdate)
    .eq("id", user.id)

  if (profileError) {
    console.error("profileError:", profileError)
    throw new Error("Failed to update profile: " + profileError.message)
  }

  // Handle verification doc separately if provided (Step 7)
  if (data.verification_doc_url && data.aadhaar_last_four) {
    // Delete any existing documents for this user first
    await supabase.from("verification_documents").delete().eq("profile_id", user.id)

    const { error: docError } = await supabase
      .from("verification_documents")
      .insert({
        profile_id: user.id,
        aadhaar_photo_path: data.verification_doc_url,
        aadhaar_last4: data.aadhaar_last_four
      })
    
    if (docError) {
      console.error("docError:", docError)
      throw new Error("Failed to upload verification document: " + docError.message)
    }
  }

  return { success: true }
}

export async function getOnboardingProgress() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()

  if (profileError || !profile) return null

  // Map backend Spec.md schema back to frontend OnboardingData schema
  return {
    ...profile,
    phone_number: profile.phone_number || "",
    avatar_url: profile.profile_photo_path || (profile.photos?.[0] || ""),
    photo_2: profile.photos?.[1] || "",
    photo_3: profile.photos?.[2] || "",
    city: profile.town || "",
    occupation: profile.profession || "",
    bio: profile.about_me || "",
    siblings: profile.siblings_count?.toString() || "0",
    manglik: profile.manglik_status || "",
    diet: profile.diet || "",
    smoking: profile.smoking || "",
    drinking: profile.drinking || "",
    hobbies: profile.hobbies || "",
    partner_age_min: profile.preferred_age_min || 18,
    partner_age_max: profile.preferred_age_max || 40,
    partner_location: profile.preferred_town || "",
    partner_religion: profile.preferred_religion || "",
    partner_caste: profile.preferred_caste || "",
    income_annual: profile.income_range === '<3L' ? 200000 : 
                   profile.income_range === '3-6L' ? 500000 :
                   profile.income_range === '6-10L' ? 800000 :
                   profile.income_range === '10-20L' ? 1500000 :
                   profile.income_range === '20L+' ? 2500000 : 0,
  }
}
